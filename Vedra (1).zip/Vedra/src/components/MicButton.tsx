import React from 'react';
import {
  TouchableOpacity,
  StyleSheet,
  View
} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialIcons';

import Colors from '../theme/colors';

type Props = {
  onPress: () => void;
};

export default function MicButton({ onPress }: Props) {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
    >
      <View style={styles.circle}>
        <Icon
          name="mic"
          size={70}
          color="white"
        />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({

  circle: {

    width: 170,

    height: 170,

    borderRadius: 85,

    backgroundColor: Colors.primary,

    justifyContent: 'center',

    alignItems: 'center',

    elevation: 8
  }

});